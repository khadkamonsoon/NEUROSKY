package com.example.dataviewer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.awt.font.NumericShaper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;

public class MainActivity<string, arr, data, Total> extends AppCompatActivity {
    InputStream inputStream;
    String[] data;

    ArrayList<Integer> totals = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputStream=getResources().openRawResource(R.raw.sample);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        int count=10;
        int i=0;
        int sum=0;

        try {
            String csvLine;
            while ((csvLine = reader.readLine()) != null) {
                String[] data = csvLine.split(",");
                int totals = Integer.parseInt(data[1]);
                for(i=0;i<10;i++){
                    sum+=sum+totals.get(i);
                    Log.e("Average",""+ sum/count);

                }

            }

                try{

                    Log.e("Data",""+ totals);
                    //Log.e("Data",""+data[0]+""+data[1]);
                }catch(Exception e){

                    Log.e("Problems",e.toString());
            }



        }



        catch (IOException ex){
            throw new RuntimeException("Error in reading CSV file:"+ex);
        }
    }
}